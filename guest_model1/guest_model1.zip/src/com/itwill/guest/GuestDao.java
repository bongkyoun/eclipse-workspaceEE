package com.itwill.guest;

public class GuestDao {

}
