package com.itwill.guest;

public class GuestService {

}
