package com.itwill.dao;

import org.apache.ibatis.session.SqlSession;

public class MyBatisMain {
	
	public static void main(String[] args) {
		System.out.println("MyBatis Test Main");
		SqlSession sqlSession;
	}
}
