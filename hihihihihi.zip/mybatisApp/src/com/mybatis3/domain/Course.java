package com.mybatis3.domain;

import java.util.Date;
public class Course 
{
	private Integer courseId;
	private String name;
	private String description;
	private Date startDate;
	private Date endDate;
	private Tutor tutor;
	
	
	
}
