package com.mybatis3.domain;

public class Tutor {
	private Integer tutorId;
	private String name;
	private String email;

}
