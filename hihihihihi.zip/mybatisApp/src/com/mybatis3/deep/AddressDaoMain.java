package com.mybatis3.deep;

public class AddressDaoMain {

	public static void main(String[] args) {
		/*******************AddressDao.findAddressById()**************/
		
	}

}
