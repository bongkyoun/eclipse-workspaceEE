package com.mybatis3.deep;

public class TutorDaoMain {

	public static void main(String[] args) {
		TutorDao tutorDao=new TutorDao();
		System.out.println("----------findTutorByIdWithCoursesAndAddress--------");
		
	}

}
